package com.example.covidtracker;


import android.os.Bundle;

import com.example.covidtracker.databinding.ActivityMainBinding;


import androidx.appcompat.app.AppCompatActivity;


import android.view.View;

import org.jsoup.Jsoup;
import android.net.Uri;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {


    private ActivityMainBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent tologin = new Intent(this, Second.class);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.adminaccess.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                startActivity(new Intent(view.getContext(), log.class));
                finish();
            }
        });

        binding.goalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(tologin);
                finish();
            }
        });



    }


}
