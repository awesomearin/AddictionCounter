package com.example.covidtracker;

import android.os.Bundle;



import androidx.appcompat.app.AppCompatActivity;

import android.view.View;


import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.content.Intent;
import android.widget.Toast;

import com.example.covidtracker.databinding.ActivitySecondBinding;

public class Second extends AppCompatActivity {

    private ActivitySecondBinding binding; //declared stringarray, referenced in crit D
    public String[] countries = new String[]{"None", "US", "India", "Japan", "Greece", "Ukraine", "China", "Italy", "Germany", "England", "Kenya", "Peru", "Mexico", "Brazil", "Australia"};
    public String savedcount1, savedcount2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); //new intents in order to navigate with confirm and cancel buttons
        Intent inter = new Intent(this, MainActivity.class);
        Intent intentium = new Intent(this, log.class);
        binding = ActivitySecondBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Spinner spinnercountries; //declared spinners and connects them to xml counterparts
        Spinner countselect2 = findViewById(R.id.count_select2);
        spinnercountries = (Spinner) findViewById(R.id.count_select);
        ArrayAdapter<String> countadapt = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, countries); //adapts the array (duh) and applies it to the spinners
        spinnercountries.setAdapter(countadapt);
        countselect2.setAdapter(countadapt);

        binding.cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //sends you back to the mainactivity
                startActivity(inter);
                finish();
            }
        });

        Spinner finalSpinnercountries = spinnercountries;
        binding.confirmButton.setOnClickListener(new View.OnClickListener(){ //sends you to the trip_display page IF you have filled out BOTH spinners
            @Override
            public void onClick(View view) {
             if (finalSpinnercountries.getSelectedItem().toString() != "None" && countselect2.getSelectedItem().toString() != "None") {

                    savedcount1 = (String)finalSpinnercountries.getSelectedItem().toString(); //toString required for this stuff
                    savedcount2 = (String)countselect2.getSelectedItem().toString();
                    intentium.putExtra("first", savedcount1);
                    intentium.putExtra("second", savedcount2);
                    System.out.println(savedcount1 + " and " + savedcount2);
                    startActivity(intentium);
                    finish();
                } else {
                 Toast.makeText(getApplicationContext(), "Fill in data first!", Toast.LENGTH_LONG).show(); //error handling
             }
            }
        });

    }
}